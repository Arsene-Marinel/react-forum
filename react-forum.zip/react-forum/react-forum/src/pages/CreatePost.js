import Post from '../components/Post'

function CreatePost({ isAuth }) {
  return <Post isAuth={isAuth} />
}

export default CreatePost;