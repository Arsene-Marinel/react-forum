import Login from '../components/Login'

const SignIn = (setIsAuth) => {
   return <Login setIsAuth={setIsAuth} />
}

export default SignIn;