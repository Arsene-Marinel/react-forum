import Register from '../components/Register'

const SignUp = (setIsAuth) => {
   return <Register />
}

export default SignUp;